#include <admodel.h>
#include <contrib.h>

  extern "C"  {
    void ad_boundf(int i);
  }
#include <lab4.htp>

model_data::model_data(int argc,char * argv[]) : ad_comm(argc,argv)
{
  nyear.allocate("nyear");
  year.allocate(1,nyear,"year");
  yield.allocate(1,nyear,"yield");
  cpue.allocate(1,nyear,"cpue");
}

model_parameters::model_parameters(int sz,int argc,char * argv[]) : 
 model_data(argc,argv) , function_minimizer(sz)
{
  initializationfunction();
  r.allocate("r");
  K.allocate("K");
  B1.allocate("B1");
  q.allocate(0,1,"q");
  logsigma.allocate("logsigma");
  biomass.allocate(1,nyear,"biomass");
  #ifndef NO_AD_INITIALIZE
    biomass.initialize();
  #endif
  logcpue.allocate(1,nyear,"logcpue");
  #ifndef NO_AD_INITIALIZE
    logcpue.initialize();
  #endif
  logcpue_pred.allocate(1,nyear,"logcpue_pred");
  #ifndef NO_AD_INITIALIZE
    logcpue_pred.initialize();
  #endif
  resid.allocate(1,nyear,"resid");
  #ifndef NO_AD_INITIALIZE
    resid.initialize();
  #endif
  effort.allocate(1,nyear,"effort");
  #ifndef NO_AD_INITIALIZE
    effort.initialize();
  #endif
  F.allocate(1,nyear,"F");
  #ifndef NO_AD_INITIALIZE
    F.initialize();
  #endif
  MSY.allocate("MSY");
  #ifndef NO_AD_INITIALIZE
  MSY.initialize();
  #endif
  Bmsy.allocate("Bmsy");
  #ifndef NO_AD_INITIALIZE
  Bmsy.initialize();
  #endif
  Fmsy.allocate("Fmsy");
  #ifndef NO_AD_INITIALIZE
  Fmsy.initialize();
  #endif
  rel_biomass.allocate("rel_biomass");
  rel_F.allocate("rel_F");
  obj_fun.allocate("obj_fun");
  prior_function_value.allocate("prior_function_value");
  likelihood_function_value.allocate("likelihood_function_value");
}

void model_parameters::preliminary_calculations(void)
{

#if defined(USE_ADPVM)

  admaster_slave_variable_interface(*this);

#endif
  cout << year << endl;
  cout << yield << endl;
  cout << cpue << endl;
  logcpue = log(cpue);
  cout << logcpue << endl;
  effort = elem_div(yield, cpue);
  cout << effort << endl;
}

void model_parameters::initializationfunction(void)
{
  r.set_initial_value(0.5);
  K.set_initial_value(200);
  B1.set_initial_value(100);
  q.set_initial_value(0.01);
  logsigma.set_initial_value(10);
}

void model_parameters::userfunction(void)
{
  obj_fun =0.0;
  biomass(1) = B1;
  for (int i=1; i<=nyear-1; i++)
  if (biomass(i)+r*biomass(i)*(1-biomass(i)/K)-yield(i)<0) biomass(i+1) = 0.001;
  else biomass(i+1) = biomass(i)+r*biomass(i)*(1-biomass(i)/K)-yield(i);
  logcpue_pred = log(q * biomass);
  resid = logcpue - logcpue_pred;
  MSY = (r * K) / 4;
  Fmsy = r / 2;
  Bmsy = K / 2;
  F = q * effort;
  rel_biomass = biomass / Bmsy;
  rel_F = F / Fmsy;
  obj_fun = sum(logsigma+(1/(2*exp(logsigma)*exp(logsigma)))*square(resid));
}

void model_parameters::report(const dvector& gradients)
{
 adstring ad_tmp=initial_params::get_reportfile_name();
  ofstream report((char*)(adprogram_name + ad_tmp));
  if (!report)
  {
    cerr << "error trying to open report file"  << adprogram_name << ".rep";
    return;
  }
  report << "CPUE residuals" << endl;
  report << resid << endl;
  report << "Biomass estimates" << endl;
  report << biomass << endl;
  report << "Fishing mortality estimates" << endl;
  report << F << endl;
  report << "MSY" << endl;
  report << MSY << endl;
  report << "Bmsy" << endl;
  report << Bmsy << endl;
  report << "Fmsy" << endl;
  report << Fmsy << endl;
  report << "Relative biomass estimates (B/Bmsy)" << endl;
  report << rel_biomass << endl;
  report << "Relative F estimates (F/Bmsy)" << endl;
  report << rel_F << endl;
}

model_data::~model_data()
{}

model_parameters::~model_parameters()
{}

void model_parameters::final_calcs(void){}

void model_parameters::set_runtime(void){}

#ifdef _BORLANDC_
  extern unsigned _stklen=10000U;
#endif


#ifdef __ZTC__
  extern unsigned int _stack=10000U;
#endif

  long int arrmblsize=0;

int main(int argc,char * argv[])
{
    ad_set_new_handler();
  ad_exit=&ad_boundf;
    gradient_structure::set_NO_DERIVATIVES();
    gradient_structure::set_YES_SAVE_VARIABLES_VALUES();
    if (!arrmblsize) arrmblsize=15000000;
    model_parameters mp(arrmblsize,argc,argv);
    mp.iprint=10;
    mp.preliminary_calculations();
    mp.computations(argc,argv);
    return 0;
}

extern "C"  {
  void ad_boundf(int i)
  {
    /* so we can stop here */
    exit(i);
  }
}
